ZDBRUS BOT 0.7.0  -  auto-play mod for Firestone: Idle Clicker Online RPG (Steam)
Website: https://zdbrus.github.io/zdbrus-bot/   Updates and bug reports: https://github.com/zdbrus/zdbrus-bot
Based on Firebot by danilogmoura (MIT). Runs inside the game, so screen size and window size don't matter.

INSTALL
1. Install MelonLoader 0.7.3 or newer on Firestone (official MelonLoader installer, point it at Firestone.exe).
2. Start the game once and close it (MelonLoader sets itself up on the first run).
3. Extract this whole zip into the game folder (the one with Firestone.exe) and say yes to replacing files.
   It adds Mods\ZdbrusBot.dll and three fixed MelonLoader files (MelonLoader\net6\Il2CppInterop.*.dll).
   Without those three files the current game closes right after loading.
   Steam: right-click Firestone > Manage > Browse local files.
   If you used Firebot before, delete Mods\firebot.dll so only one bot runs.
4. Start the game from Steam.

KEYS
F1 settings panel   F2 task status   F7 start / stop the bot
F4 War Machine Planner (opens in your browser at http://localhost:5577)
F6 auto upgrade     F8 auto skill    F9 save a screen map (for bug reports)

WHAT IT DOES
Firebot features: daily rewards and check-in, free shop items, quests, map missions, Warfront loot,
Firestone research (with priority), alchemy, Oracle rituals, engineer tools, guardian training,
expeditions, free pickaxes, auto skills, auto upgrades.
Added in Zdbrus Bot: quest rewards (daily and weekly), reacts to the notification bubbles, clicks coal miners and double-beer dragons the moment they appear, mail rewards, tavern (beer to tokens, cards), exotic merchant (sell, upgrades,
emblem chests), guild crystal, Chaos Rift (hits, eclipse stones, tomes, holy upgrades per guardian), Oracle blessings, personal tree, hero awakening, war machine levels and blueprints,
event challenge rewards, Liberation missions, Arena fights (easiest opponent, free refresh), and the F9 screen map.
New in 0.6.0: Meteorite research (priority list), Forbidden knowledge (tomes, per god), Scarab's game (Noble's token
spins only), Pharaoh's vault, Scarab milestones, seasonal event exchange (e.g. pumpkins for pickaxes, chests),
battle pass free rewards, free rewards from other notification bubbles, and Temple prestige when your run stalls
(no new highest stage for 3 hours, adjustable in F1). The bot tells you when a new version is out.
New in 0.7.0: War Machine Planner (F4). Reads your real war machines, crews, heroes and jewels from the game,
builds the strongest squad and crews for the campaign or the arena, and with "Apply to game" sets that squad in
the Engineer for you. Hero faces come from your own game (open Engineer > Select crew once). It is only
reachable from your own PC.

SAFETY
It never spends gems or real money. Every purchase is skipped unless the game shows the button as
available and you have enough of the currency it costs.
Using bots may break the game's terms of service. Use at your own risk.
